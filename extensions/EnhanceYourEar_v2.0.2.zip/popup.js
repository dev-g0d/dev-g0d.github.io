document.addEventListener('DOMContentLoaded', () => {
  console.log('Popup loaded');
  
  const volumeSlider = document.getElementById('volume');
  const bassSlider = document.getElementById('bass');
  const reverbSlider = document.getElementById('reverb');
  const volValue = document.getElementById('volValue');
  const bassValue = document.getElementById('bassValue');
  const reverbValue = document.getElementById('reverbValue');
  const toggleButton = document.getElementById('toggle');
  const optimizeButton = document.getElementById('optimize');
  const concertButton = document.getElementById('concert');
  const errorDiv = document.getElementById('error');

  let tabId = null;
  let isEnabled = false;

  chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
    if (tabs[0]) {
      tabId = tabs[0].id;
      console.log('Current tab ID:', tabId);
      
      chrome.storage.local.get([`tab_${tabId}`], (data) => {
        const tabData = data[`tab_${tabId}`] || {};
        console.log('Loaded stored values for tab:', tabData);
        volumeSlider.value = tabData.volume || 100;
        bassSlider.value = tabData.bass || 0;
        reverbSlider.value = tabData.reverb || 0;
        isEnabled = tabData.isEnabled || false;
        updateUI();
      });
    } else {
      console.error('No active tab found');
      errorDiv.textContent = 'No active tab found. Please try again.';
      errorDiv.style.display = 'block';
    }
  });

  volumeSlider.addEventListener('input', () => updateAudio());
  bassSlider.addEventListener('input', () => updateAudio());
  reverbSlider.addEventListener('input', () => updateAudio());
  toggleButton.addEventListener('click', () => toggleAudio());
  optimizeButton.addEventListener('click', () => enhanceMode());
  concertButton.addEventListener('click', () => concertMode());

  function updateUI() {
    volValue.textContent = `${volumeSlider.value}%`;
    bassValue.textContent = `${bassSlider.value}%`;
    reverbValue.textContent = `${reverbSlider.value}%`;
    toggleButton.textContent = isEnabled ? 'Turn Off' : 'Turn On';
    toggleButton.classList.toggle('active', isEnabled);
  }

  function updateAudio() {
    const volume = volumeSlider.value;
    const bass = bassSlider.value;
    const reverb = reverbSlider.value;

    updateUI();

    chrome.storage.local.set({
      [`tab_${tabId}`]: { volume, bass, reverb, isEnabled }
    });

    if (isEnabled) {
      chrome.tabs.sendMessage(tabId, {
        type: 'updateAudio',
        volume: (volume / 100) * 1.3,
        bass: (bass / 100) * 8,
        reverb: (reverb / 100) * 0.5
      }, (response) => {
        if (chrome.runtime.lastError) {
          console.error('Error sending message:', chrome.runtime.lastError);
          errorDiv.textContent = 'Failed to connect to audio. Try refreshing the page.';
          errorDiv.style.display = 'block';
        } else {
          errorDiv.style.display = response?.success ? 'none' : 'block';
        }
      });
    }
  }

  function toggleAudio() {
    isEnabled = !isEnabled;
    chrome.storage.local.set({
      [`tab_${tabId}`]: {
        volume: volumeSlider.value,
        bass: bassSlider.value,
        reverb: reverbSlider.value,
        isEnabled
      }
    });
    updateUI();

    chrome.tabs.sendMessage(tabId, {
      type: isEnabled ? 'enableAudio' : 'disableAudio',
      volume: (volumeSlider.value / 100) * 1.3,
      bass: (bassSlider.value / 100) * 8,
      reverb: (reverbSlider.value / 100) * 0.5
    }, (response) => {
      if (chrome.runtime.lastError) {
        console.error('Error sending toggle message:', chrome.runtime.lastError);
        errorDiv.textContent = 'Failed to connect to audio. Try refreshing the page.';
        errorDiv.style.display = 'block';
      } else {
        errorDiv.style.display = response?.success ? 'none' : 'block';
      }
    });
  }

  function concertMode() {
    volumeSlider.value = 140;
    bassSlider.value = 30;
    reverbSlider.value = 92;
    isEnabled = true;
    chrome.storage.local.set({
      [`tab_${tabId}`]: {
        volume: volumeSlider.value,
        bass: bassSlider.value,
        reverb: reverbSlider.value,
        isEnabled
      }
    });
    updateUI();

    chrome.tabs.sendMessage(tabId, { type: 'concertMode' }, (response) => {
      if (chrome.runtime.lastError) {
        console.error('Error sending concert message:', chrome.runtime.lastError);
        errorDiv.textContent = 'Failed to connect to audio. Try refreshing the page.';
        errorDiv.style.display = 'block';
      } else {
        errorDiv.style.display = response?.success ? 'none' : 'block';
      }
    });
  }

  function enhanceMode() {
    volumeSlider.value = 130;
    bassSlider.value = 60;
    reverbSlider.value = 50;
    isEnabled = true;
    chrome.storage.local.set({
      [`tab_${tabId}`]: {
        volume: volumeSlider.value,
        bass: bassSlider.value,
        reverb: reverbSlider.value,
        isEnabled
      }
    });
    updateUI();

    chrome.tabs.sendMessage(tabId, { type: 'enhanceMode' }, (response) => {
      if (chrome.runtime.lastError) {
        console.error('Error sending enhance message:', chrome.runtime.lastError);
        errorDiv.textContent = 'Failed to connect to audio. Try refreshing the page.';
        errorDiv.style.display = 'block';
      } else {
        errorDiv.style.display = response?.success ? 'none' : 'block';
      }
    });
  }
});
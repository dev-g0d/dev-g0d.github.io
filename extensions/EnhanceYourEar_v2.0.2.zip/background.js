chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.type === 'getTabId') {
    sendResponse({ tabId: sender.tabId });
  }
});

chrome.tabs.onRemoved.addListener((tabId) => {
  console.log('Tab closed, ID:', tabId);
  chrome.storage.local.remove(`tab_${tabId}`, () => {
    console.log(`Cleared storage for tab_${tabId}`);
  });
});

chrome.runtime.onInstalled.addListener((details) => {
  if (details.reason === 'install') {
    chrome.tabs.create({ url: 'https://dev-g0d.github.io/' });
  }
});
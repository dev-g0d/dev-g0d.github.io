let audioContext = null;
let gainNode = null;
let bassFilter = null;
let punchFilter = null;
let reverbNode = null;
let wetGain = null;
let audioSources = new Map();
let isEnabled = false;

function initializeAudio() {
  console.log('Initializing AudioContext');
  if (!audioContext) {
    try {
      audioContext = new AudioContext();
      gainNode = audioContext.createGain();
      bassFilter = audioContext.createBiquadFilter();
      punchFilter = audioContext.createBiquadFilter();
      reverbNode = audioContext.createConvolver();
      wetGain = audioContext.createGain();

      bassFilter.type = 'lowshelf';
      bassFilter.frequency.value = 90;
      bassFilter.gain.value = 0;

      punchFilter.type = 'peaking';
      punchFilter.frequency.value = 70;
      punchFilter.Q.value = 1.2;
      punchFilter.gain.value = 0;

      const sampleRate = audioContext.sampleRate;
      const length = sampleRate * 3;
      const impulse = audioContext.createBuffer(2, length, sampleRate);
      const impulseL = impulse.getChannelData(0);
      const impulseR = impulse.getChannelData(1);
      for (let i = 0; i < length; i++) {
        const decay = (1 - i / length) ** 1.8;
        impulseL[i] = (Math.random() * 2 - 1) * decay * 0.45;
        impulseR[i] = (Math.random() * 2 - 1) * decay * 0.45;
      }
      reverbNode.buffer = impulse;

      reverbNode.connect(wetGain);
      wetGain.connect(gainNode);

      const audioElements = document.querySelectorAll('audio, video');
      console.log('Found audio elements:', audioElements.length);
      audioElements.forEach((element) => {
        connectAudioElement(element);
      });

      const observer = new MutationObserver((mutations) => {
        mutations.forEach((mutation) => {
          const newAudioElements = document.querySelectorAll('audio, video');
          newAudioElements.forEach((element) => {
            if (!audioSources.has(element)) {
              connectAudioElement(element);
            }
          });
        });
      });

      observer.observe(document.body, { childList: true, subtree: true });
    } catch (e) {
      console.error('Error initializing AudioContext:', e);
      return false;
    }
    return true;
  }
  return true;
}

function connectAudioElement(element) {
  try {
    if (!audioSources.has(element)) {
      const source = audioContext.createMediaElementSource(element);
      source.connect(bassFilter);
      bassFilter.connect(punchFilter);
      punchFilter.connect(reverbNode);
      punchFilter.connect(gainNode);
      gainNode.connect(audioContext.destination);
      audioSources.set(element, source);
      console.log('Connected audio element:', element);
    }
  } catch (e) {
    console.error('Error connecting audio element:', e);
  }
}

function resetAudio() {
  isEnabled = false;
  if (gainNode) gainNode.gain.value = 1;
  if (bassFilter) bassFilter.gain.value = 0;
  if (punchFilter) punchFilter.gain.value = 0;
  if (wetGain) wetGain.gain.value = 0;
  if (audioContext) {
    audioContext.close();
    audioContext = null;
  }
  audioSources.clear();
}

resetAudio();

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  console.log('Message received in content.js:', message);

  if (message.type === 'updateAudio' || message.type === 'enableAudio') {
    if (!audioContext) {
      if (!initializeAudio()) {
        sendResponse({ success: false });
        return;
      }
    }
    isEnabled = true;

    try {
      if (gainNode) gainNode.gain.value = message.volume;
      if (bassFilter) bassFilter.gain.value = message.bass;
      if (punchFilter) punchFilter.gain.value = message.bass * 0.75;
      if (wetGain) wetGain.gain.value = message.reverb;
      sendResponse({ success: true });
    } catch (e) {
      console.error('Error updating audio:', e);
      sendResponse({ success: false });
    }
  } else if (message.type === 'disableAudio') {
    isEnabled = false;
    try {
      if (gainNode) gainNode.gain.value = 1;
      if (bassFilter) bassFilter.gain.value = 0;
      if (punchFilter) punchFilter.gain.value = 0;
      if (wetGain) wetGain.gain.value = 0;
      sendResponse({ success: true });
    } catch (e) {
      console.error('Error disabling audio:', e);
      sendResponse({ success: false });
    }
  } else if (message.type === 'concertMode') {
    if (!audioContext) {
      if (!initializeAudio()) {
        sendResponse({ success: false });
        return;
      }
    }
    isEnabled = true;

    try {
      if (gainNode) gainNode.gain.value = 1.4;
      if (bassFilter) bassFilter.gain.value = 8;
      if (punchFilter) punchFilter.gain.value = 7;
      if (wetGain) wetGain.gain.value = 1.7;
      sendResponse({ success: true });
    } catch (e) {
      console.error('Error applying concert mode:', e);
      sendResponse({ success: false });
    }
  } else if (message.type === 'enhanceMode') {
    if (!audioContext) {
      if (!initializeAudio()) {
        sendResponse({ success: false });
        return;
      }
    }
    isEnabled = true;

    try {
      if (gainNode) gainNode.gain.value = 1.3;
      if (bassFilter) bassFilter.gain.value = 8;
      if (punchFilter) punchFilter.gain.value = 6;
      if (wetGain) wetGain.gain.value = 0.5;
      sendResponse({ success: true });
    } catch (e) {
      console.error('Error applying enhance mode:', e);
      sendResponse({ success: false });
    }
  }
});
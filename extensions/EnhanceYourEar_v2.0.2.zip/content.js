let audioContext = null;
let gainNode = null;
let bassFilter = null;
let reverbNode = null;
let wetGain = null;
let audioSources = new Map();
let isEnabled = false;

function initializeAudio() {
  console.log('Initializing AudioContext');
  if (!audioContext) {
    try {
      audioContext = new AudioContext();
      gainNode = audioContext.createGain();
      bassFilter = audioContext.createBiquadFilter();
      reverbNode = audioContext.createConvolver();
      wetGain = audioContext.createGain();

      bassFilter.type = 'lowshelf';
      bassFilter.frequency.value = 200;
      bassFilter.gain.value = 0;

      const sampleRate = audioContext.sampleRate;
      const length = sampleRate * 2;
      const impulse = audioContext.createBuffer(2, length, sampleRate);
      const impulseL = impulse.getChannelData(0);
      const impulseR = impulse.getChannelData(1);
      for (let i = 0; i < length; i++) {
        const decay = (1 - i / length) ** 2;
        impulseL[i] = (Math.random() * 2 - 1) * decay;
        impulseR[i] = (Math.random() * 2 - 1) * decay;
      }
      reverbNode.buffer = impulse;

      reverbNode.connect(wetGain);
      wetGain.connect(gainNode);
      wetGain.gain.value = 0;

      const audioElements = document.querySelectorAll('audio, video');
      console.log('Found audio elements:', audioElements.length);
      audioElements.forEach((element) => {
        connectAudioElement(element);
      });

      const observer = new MutationObserver((mutations) => {
        mutations.forEach((mutation) => {
          const newAudioElements = document.querySelectorAll('audio, video');
          newAudioElements.forEach((element) => {
            if (!audioSources.has(element)) {
              connectAudioElement(element);
            }
          });
        });
      });

      observer.observe(document.body, { childList: true, subtree: true });
    } catch (e) {
      console.error('Error initializing AudioContext:', e);
      return false;
    }
    return true;
  }
  return true;
}

function connectAudioElement(element) {
  try {
    if (!audioSources.has(element)) {
      const source = audioContext.createMediaElementSource(element);
      source.connect(bassFilter);
      bassFilter.connect(reverbNode);
      bassFilter.connect(gainNode);
      gainNode.connect(audioContext.destination);
      audioSources.set(element, source);
      console.log('Connected audio element:', element);
    }
  } catch (e) {
    console.error('Error connecting audio element:', e);
  }
}

function resetAudio() {
  isEnabled = false;
  if (gainNode) {
    gainNode.gain.value = 1;
  }
  if (bassFilter) {
    bassFilter.gain.value = 0;
  }
  if (wetGain) {
    wetGain.gain.value = 0;
  }
  if (audioContext) {
    audioContext.close();
    audioContext = null;
  }
  audioSources.clear();
}

resetAudio();

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  console.log('Message received in content.js:', message);

  if (message.type === 'updateAudio' || message.type === 'enableAudio') {
    if (!audioContext) {
      if (!initializeAudio()) {
        sendResponse({ success: false });
        return;
      }
    }
    isEnabled = true;

    try {
      if (gainNode) {
        gainNode.gain.value = message.volume;
        console.log('Volume set to:', message.volume);
      }
      if (bassFilter) {
        bassFilter.gain.value = message.bass * 20;
        console.log('Bass set to:', message.bass * 20);
      }
      if (wetGain) {
        wetGain.gain.value = message.reverb;
        console.log('Reverb set to:', message.reverb);
      }
      sendResponse({ success: true });
    } catch (e) {
      console.error('Error updating audio:', e);
      sendResponse({ success: false });
    }
  } else if (message.type === 'disableAudio') {
    isEnabled = false;
    try {
      if (gainNode) {
        gainNode.gain.value = 1;
        console.log('Volume reset for disable');
      }
      if (bassFilter) {
        bassFilter.gain.value = 0;
        console.log('Bass reset for disable');
      }
      if (wetGain) {
        wetGain.gain.value = 0;
        console.log('Reverb reset for disable');
      }
      sendResponse({ success: true });
    } catch (e) {
      console.error('Error disabling audio:', e);
      sendResponse({ success: false });
    }
  }
});